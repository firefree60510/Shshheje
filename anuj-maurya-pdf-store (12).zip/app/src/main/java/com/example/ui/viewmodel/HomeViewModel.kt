package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppSettings
import com.example.data.model.PdfItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeUiState(
    val isLoading: Boolean = false,
    val pdfs: List<PdfItem> = emptyList(),
    val appSettings: AppSettings = AppSettings(),
    val selectedClass: String = "All",
    val selectedCategory: String = "All",
    val searchQuery: String = "",
    val error: String? = null
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)

    private val _uiState = MutableStateFlow(HomeUiState(isLoading = true))
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            val settingsRes = repository.getSettings()
            val settings = settingsRes.getOrNull() ?: repository.getLocalSettings()

            val pdfsRes = repository.getPdfs(
                boardClass = if (_uiState.value.selectedClass == "All") null else _uiState.value.selectedClass,
                category = if (_uiState.value.selectedCategory == "All") null else _uiState.value.selectedCategory,
                searchQuery = _uiState.value.searchQuery.ifBlank { null }
            )

            val pdfs = pdfsRes.getOrNull() ?: emptyList()

            _uiState.update {
                it.copy(
                    isLoading = false,
                    pdfs = pdfs,
                    appSettings = settings,
                    error = if (pdfs.isEmpty() && it.searchQuery.isBlank() && it.selectedClass == "All") "No PDF materials available." else null
                )
            }
        }
    }

    fun selectClass(boardClass: String) {
        _uiState.update { it.copy(selectedClass = boardClass) }
        loadPdfsOnly()
    }

    fun selectCategory(category: String) {
        _uiState.update { it.copy(selectedCategory = category) }
        loadPdfsOnly()
    }

    fun search(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        loadPdfsOnly()
    }

    private fun loadPdfsOnly() {
        viewModelScope.launch {
            val pdfsRes = repository.getPdfs(
                boardClass = if (_uiState.value.selectedClass == "All") null else _uiState.value.selectedClass,
                category = if (_uiState.value.selectedCategory == "All") null else _uiState.value.selectedCategory,
                searchQuery = _uiState.value.searchQuery.ifBlank { null }
            )
            val pdfs = pdfsRes.getOrNull() ?: emptyList()
            _uiState.update { it.copy(pdfs = pdfs) }
        }
    }
}
