package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.R

fun formatGoogleDriveImageUrl(url: String?): String? {
    if (url.isNullOrBlank()) return null
    val trimmed = url.trim()
    // Match /file/d/ID/
    val fileIdMatch = Regex("/file/d/([a-zA-Z0-9_-]+)").find(trimmed)
    if (fileIdMatch != null) {
        val fileId = fileIdMatch.groupValues[1]
        return "https://lh3.googleusercontent.com/d/$fileId"
    }
    // Match id=ID
    val idParamMatch = Regex("[?&]id=([a-zA-Z0-9_-]+)").find(trimmed)
    if (idParamMatch != null && trimmed.contains("drive.google.com")) {
        val fileId = idParamMatch.groupValues[1]
        return "https://lh3.googleusercontent.com/d/$fileId"
    }
    return trimmed
}

@Composable
fun AnujMauryaLogoView(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    customUrl: String? = null
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (!customUrl.isNullOrBlank()) {
            val formattedUrl = formatGoogleDriveImageUrl(customUrl) ?: customUrl
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(formattedUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Anuj Maurya Logo",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                loading = {
                    DefaultLogoImage()
                },
                error = {
                    DefaultLogoImage()
                }
            )
        } else {
            DefaultLogoImage()
        }
    }
}

@Composable
private fun DefaultLogoImage() {
    Image(
        painter = painterResource(id = R.drawable.anuj_maurya_exact_photo),
        contentDescription = "Anuj Maurya Official Logo",
        modifier = Modifier
            .fillMaxSize()
            .clip(CircleShape),
        contentScale = ContentScale.Crop
    )
}
