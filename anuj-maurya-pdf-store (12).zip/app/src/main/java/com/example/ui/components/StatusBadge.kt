package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.RedError

@Composable
fun StatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, label) = when (status.lowercase()) {
        "approved", "completed", "delivered" -> Triple(GreenSuccess.copy(alpha = 0.15f), GreenSuccess, "Approved ✓")
        "rejected", "cancelled" -> Triple(RedError.copy(alpha = 0.15f), RedError, "Rejected ✗")
        else -> Triple(AmberAccent.copy(alpha = 0.2f), Color(0xFFB45309), "Verification Pending ⏳")
    }

    Text(
        text = label,
        color = textColor,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier
            .background(bgColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}
