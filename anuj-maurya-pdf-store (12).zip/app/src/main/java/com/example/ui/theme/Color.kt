package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF0D47A1)
val BlueSecondary = Color(0xFF1976D2)
val BlueDark = Color(0xFF002171)
val BlueLight = Color(0xFF5472D3)

val AmberAccent = Color(0xFFFFB300)
val AmberDark = Color(0xFFC68400)
val AmberLight = Color(0xFFFFE54C)

val GreenSuccess = Color(0xFF2E7D32)
val RedError = Color(0xFFC62828)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)

val AdminNavy = Color(0xFF0F172A)
val AdminCardBg = Color(0xFF1E293B)
