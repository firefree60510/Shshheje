package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AdminStats
import com.example.data.model.AppSettings
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AdminUiState(
    val isLoggedIn: Boolean = false,
    val usernameInput: String = "anujadmin",
    val pinInput: String = "",
    val activeTab: Int = 0, // 0: Orders, 1: Posts/PDFs, 2: Settings, 3: Banners
    val orders: List<OrderItem> = emptyList(),
    val stats: AdminStats = AdminStats(),
    val statusFilter: String = "All",
    val pdfs: List<PdfItem> = emptyList(),
    val appSettings: AppSettings = AppSettings(),
    val isLoading: Boolean = false,
    val successMessage: String? = null,
    val errorMessage: String? = null
)

class AdminViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        AdminUiState(
            isLoggedIn = preferences.isAdminLoggedIn
        )
    )
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        if (_uiState.value.isLoggedIn) {
            loadAllAdminData()
        }
    }

    fun onUsernameChange(u: String) {
        _uiState.update { it.copy(usernameInput = u) }
    }

    fun onPinChange(p: String) {
        _uiState.update { it.copy(pinInput = p) }
    }

    fun setTab(index: Int) {
        _uiState.update { it.copy(activeTab = index) }
    }

    fun setStatusFilter(filter: String) {
        _uiState.update { it.copy(statusFilter = filter) }
        loadOrders()
    }

    fun login() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val res = repository.adminLogin(state.usernameInput.trim(), state.pinInput.trim())
            if (res.isSuccess) {
                _uiState.update { it.copy(isLoggedIn = true, isLoading = false, errorMessage = null) }
                loadAllAdminData()
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = res.exceptionOrNull()?.localizedMessage ?: "Invalid Admin Credentials"
                    )
                }
            }
        }
    }

    fun logout() {
        preferences.isAdminLoggedIn = false
        _uiState.update { it.copy(isLoggedIn = false, pinInput = "") }
    }

    fun loadAllAdminData() {
        loadOrders()
        loadPdfs()
        loadSettings()
    }

    fun loadOrders() {
        viewModelScope.launch {
            val filter = if (_uiState.value.statusFilter == "All") null else _uiState.value.statusFilter
            val res = repository.getAdminOrders(filter)
            if (res.isSuccess) {
                val pair = res.getOrNull()!!
                _uiState.update { it.copy(stats = pair.first, orders = pair.second) }
            }
        }
    }

    fun loadPdfs() {
        viewModelScope.launch {
            val res = repository.getPdfs()
            if (res.isSuccess) {
                _uiState.update { it.copy(pdfs = res.getOrNull() ?: emptyList()) }
            }
        }
    }

    fun loadSettings() {
        viewModelScope.launch {
            val res = repository.getSettings()
            if (res.isSuccess) {
                _uiState.update { it.copy(appSettings = res.getOrNull() ?: repository.getLocalSettings()) }
            }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String, message: String?) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.updateAdminOrderStatus(orderId, newStatus, message)
            _uiState.update { it.copy(isLoading = false, successMessage = "Order $orderId updated to $newStatus") }
            loadOrders()
        }
    }

    fun addPost(pdf: PdfItem, coverUri: Uri?) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val coverUrl = if (coverUri != null) repository.saveCoverImageToInternalStorage(coverUri) else pdf.previewImageUrl
            val newPdf = pdf.copy(previewImageUrl = coverUrl)
            repository.addPdf(newPdf)
            _uiState.update { it.copy(isLoading = false, successMessage = "New PDF Material published successfully!") }
            loadPdfs()
        }
    }

    fun deletePost(id: Long) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.deletePdf(id)
            _uiState.update { it.copy(isLoading = false, successMessage = "Post deleted successfully.") }
            loadPdfs()
        }
    }

    fun deleteAllPosts() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.deleteAllPdfs()
            _uiState.update { it.copy(isLoading = false, successMessage = "All posts deleted.") }
            loadPdfs()
        }
    }

    fun saveSettings(
        upiId: String,
        upiName: String,
        announcement: String,
        whatsapp: String,
        youtubeUrl: String,
        telegramUrl: String,
        upiQrUri: Uri?,
        appLogoUri: Uri?,
        appLogoDirectUrl: String? = null
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val qrUrl = if (upiQrUri != null) repository.saveQrUriToInternalStorage(upiQrUri) else null
            if (appLogoUri != null) {
                repository.updateAdminLogo(appLogoUri)
            } else if (!appLogoDirectUrl.isNullOrBlank()) {
                repository.updateAdminSettings(
                    upiId = upiId,
                    upiName = upiName,
                    announcement = announcement,
                    whatsapp = whatsapp,
                    youtubeUrl = youtubeUrl,
                    telegramUrl = telegramUrl,
                    upiQrUrl = qrUrl
                )
                preferences.appLogoUrl = appLogoDirectUrl.trim()
                if (repository.firestore.isAvailable()) {
                    val current = repository.getLocalSettings().copy(appLogoUrl = appLogoDirectUrl.trim())
                    repository.firestore.saveAppSettings(current)
                }
            }
            repository.updateAdminSettings(
                upiId = upiId,
                upiName = upiName,
                announcement = announcement,
                whatsapp = whatsapp,
                youtubeUrl = youtubeUrl,
                telegramUrl = telegramUrl,
                upiQrUrl = qrUrl
            )
            _uiState.update { it.copy(isLoading = false, successMessage = "Settings saved successfully!") }
            loadSettings()
        }
    }

    fun saveBanners(banners: List<BannerItem>) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.updateAdminBanners(banners)
            _uiState.update { it.copy(isLoading = false, successMessage = "YouTube Banners updated successfully!") }
            loadSettings()
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(successMessage = null, errorMessage = null) }
    }
}
