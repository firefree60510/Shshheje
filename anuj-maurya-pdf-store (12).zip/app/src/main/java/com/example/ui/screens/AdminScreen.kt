package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AdminCardBg
import com.example.ui.theme.AdminNavy
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.BlueSecondary
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.RedError
import com.example.ui.viewmodel.AdminViewModel
import com.example.util.WhatsAppHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(uiState.successMessage) {
        if (uiState.successMessage != null) {
            Toast.makeText(context, uiState.successMessage, Toast.LENGTH_SHORT).show()
            viewModel.clearMessages()
        }
    }

    if (!uiState.isLoggedIn) {
        AdminLoginView(
            viewModel = viewModel,
            onBackClick = onBackClick
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Anuj Maurya Admin Panel", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Cloud Firestore Live Sync", fontSize = 11.sp, color = AmberAccent)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.loadAllAdminData() }) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                        }
                        IconButton(onClick = { viewModel.logout() }) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = Color(0xFFFCA5A5))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = AdminNavy,
                        titleContentColor = Color.White
                    )
                )
            },
            containerColor = Color(0xFF0F172A)
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Tab Row
                TabRow(
                    selectedTabIndex = uiState.activeTab,
                    containerColor = Color(0xFF1E293B),
                    contentColor = AmberAccent
                ) {
                    Tab(
                        selected = uiState.activeTab == 0,
                        onClick = { viewModel.setTab(0) },
                        text = { Text("Orders (${uiState.orders.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = uiState.activeTab == 1,
                        onClick = { viewModel.setTab(1) },
                        text = { Text("Post PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = uiState.activeTab == 2,
                        onClick = { viewModel.setTab(2) },
                        text = { Text("Settings", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = uiState.activeTab == 3,
                        onClick = { viewModel.setTab(3) },
                        text = { Text("Banners", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                when (uiState.activeTab) {
                    0 -> AdminOrdersTab(viewModel = viewModel)
                    1 -> AdminPostsTab(viewModel = viewModel)
                    2 -> AdminSettingsTab(viewModel = viewModel)
                    3 -> AdminBannersTab(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
private fun AdminLoginView(viewModel: AdminViewModel, onBackClick: () -> Unit) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AdminNavy)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = AmberAccent.copy(alpha = 0.2f),
            modifier = Modifier.size(72.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = AmberAccent,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Admin Portal Login",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )
        Text(
            text = "Anuj Maurya PDF Store Management",
            fontSize = 12.sp,
            color = Color.LightGray
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardBg)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                OutlinedTextField(
                    value = uiState.usernameInput,
                    onValueChange = { viewModel.onUsernameChange(it) },
                    label = { Text("Admin Username", color = Color.LightGray) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = AmberAccent) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_username_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AmberAccent,
                        unfocusedBorderColor = Color(0xFF475569)
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = uiState.pinInput,
                    onValueChange = { viewModel.onPinChange(it) },
                    label = { Text("4-Digit PIN (Default: 1234)", color = Color.LightGray) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = AmberAccent) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_pin_input"),
                    shape = RoundedCornerShape(10.dp),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AmberAccent,
                        unfocusedBorderColor = Color(0xFF475569)
                    ),
                    singleLine = true
                )

                if (uiState.errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = uiState.errorMessage ?: "",
                        color = Color(0xFFF87171),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = { viewModel.login() },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("admin_login_submit_btn")
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(color = Color(0xFF0F172A), modifier = Modifier.size(20.dp))
                    } else {
                        Text("Log In as Admin", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = onBackClick) {
            Text("← Back to Student Store", color = Color.LightGray)
        }
    }
}

@Composable
private fun AdminOrdersTab(viewModel: AdminViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val filters = listOf("All", "Pending", "Approved", "Rejected")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Stats Overview Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AdminStatCard(title = "Total Orders", value = "${uiState.stats.totalOrders}", color = Color(0xFF38BDF8), modifier = Modifier.weight(1f))
                AdminStatCard(title = "Pending", value = "${uiState.stats.pendingOrders}", color = AmberAccent, modifier = Modifier.weight(1f))
                AdminStatCard(title = "Approved", value = "${uiState.stats.approvedOrders}", color = GreenSuccess, modifier = Modifier.weight(1f))
                AdminStatCard(title = "Revenue", value = "₹${uiState.stats.totalRevenue.toInt()}", color = Color(0xFFA855F7), modifier = Modifier.weight(1f))
            }
        }

        // Filter chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { filter ->
                    val isSelected = uiState.statusFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setStatusFilter(filter) },
                        label = { Text(filter, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberAccent,
                            selectedLabelColor = Color(0xFF0F172A),
                            containerColor = AdminCardBg,
                            labelColor = Color.White
                        )
                    )
                }
            }
        }

        if (uiState.orders.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No orders in this category.", color = Color.Gray, fontSize = 14.sp)
                }
            }
        }

        items(uiState.orders, key = { it.orderId }) { order ->
            AdminOrderCard(
                order = order,
                onUpdateStatus = { newStatus, message ->
                    viewModel.updateOrderStatus(order.orderId, newStatus, message)
                }
            )
        }
    }
}

@Composable
private fun AdminStatCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCardBg)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 10.sp, color = Color.LightGray, maxLines = 1)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
private fun AdminOrderCard(
    order: OrderItem,
    onUpdateStatus: (String, String?) -> Unit
) {
    val context = LocalContext.current
    var showScreenshotDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCardBg)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = order.orderId, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = AmberAccent)
                StatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(text = order.pdfTitle, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = "Amount: ₹${order.pdfPrice.toInt()}", fontSize = 13.sp, color = AmberAccent, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(6.dp))

            Text(text = "Student: ${order.studentName}", fontSize = 12.sp, color = Color.LightGray)
            Text(text = "WhatsApp: ${order.whatsappNumber}", fontSize = 12.sp, color = Color.LightGray)

            if (!order.utrNumber.isNullOrBlank()) {
                Text(text = "UTR: ${order.utrNumber}", fontSize = 12.sp, color = Color(0xFF38BDF8))
            }

            if (!order.createdAt.isNullOrBlank()) {
                Text(text = "Date: ${order.createdAt}", fontSize = 11.sp, color = Color.Gray)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Screenshot Preview Button
            if (!order.screenshotUrl.isNullOrBlank()) {
                Button(
                    onClick = { showScreenshotDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("View Payment Screenshot", fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Quick Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onUpdateStatus("Approved", "Payment verified by Admin. Download unlocked!") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Approve", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onUpdateStatus("Rejected", "Payment screenshot not matching or invalid.") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        WhatsAppHelper.openWhatsAppChat(
                            context = context,
                            phoneNumber = order.whatsappNumber,
                            message = "Hello ${order.studentName}, regarding your Order ID: ${order.orderId} for ${order.pdfTitle}."
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showScreenshotDialog && !order.screenshotUrl.isNullOrBlank()) {
        AlertDialog(
            onDismissRequest = { showScreenshotDialog = false },
            title = { Text("Payment Screenshot (${order.orderId})") },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AsyncImage(
                        model = order.screenshotUrl,
                        contentDescription = "Full Screenshot",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Fit
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showScreenshotDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminPostsTab(viewModel: AdminViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    var title by remember { mutableStateOf("") }
    var boardClass by remember { mutableStateOf("Class 10") }
    var subject by remember { mutableStateOf("Mathematics") }
    var category by remember { mutableStateOf("Notes") }
    var price by remember { mutableStateOf("29") }
    var originalPrice by remember { mutableStateOf("99") }
    var description by remember { mutableStateOf("") }
    var pagesCount by remember { mutableStateOf("50") }
    var fileSize by remember { mutableStateOf("3.5 MB") }
    var downloadUrl by remember { mutableStateOf("") }
    var coverUri by remember { mutableStateOf<Uri?>(null) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        coverUri = uri
    }

    val classOptions = listOf("Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12")
    val categoryOptions = listOf("Notes", "Important Papers", "Model Papers", "Previous Year Papers", "Important Questions")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Form Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AdminCardBg)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "➕ Post New PDF Study Material",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Title (e.g. Class 10 Science Topper Notes)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = boardClass,
                            onValueChange = { boardClass = it },
                            label = { Text("Class") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("Subject") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("Category") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it },
                            label = { Text("Price (₹)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = originalPrice,
                            onValueChange = { originalPrice = it },
                            label = { Text("Original (₹)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description & Topics Covered") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = downloadUrl,
                        onValueChange = { downloadUrl = it },
                        label = { Text("Google Drive / PDF Download URL") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Cover Picker
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFF475569), RoundedCornerShape(8.dp))
                            .clickable {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                        color = Color(0xFF0F172A)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, tint = AmberAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (coverUri != null) "Cover Image Selected ✓" else "Select PDF Cover Image (Optional)",
                                color = if (coverUri != null) GreenSuccess else Color.LightGray,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (title.isBlank()) return@Button
                            val pdf = PdfItem(
                                id = 0,
                                title = title.trim(),
                                boardClass = boardClass.trim(),
                                subject = subject.trim(),
                                category = category.trim(),
                                price = price.toDoubleOrNull() ?: 29.0,
                                originalPrice = originalPrice.toDoubleOrNull() ?: 99.0,
                                description = description.trim().ifBlank { null },
                                pagesCount = pagesCount.toIntOrNull() ?: 45,
                                fileSize = fileSize.trim(),
                                year = "2026",
                                isAvailable = true,
                                isFeatured = true,
                                downloadUrl = downloadUrl.trim().ifBlank { null }
                            )
                            viewModel.addPost(pdf, coverUri)
                            title = ""
                            description = ""
                            downloadUrl = ""
                            coverUri = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Publish PDF Material to Cloud", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Existing Posts list
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Published Materials (${uiState.pdfs.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                TextButton(
                    onClick = { showDeleteAllDialog = true }
                ) {
                    Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = RedError, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete All", color = RedError, fontSize = 12.sp)
                }
            }
        }

        items(uiState.pdfs, key = { it.id }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = AdminCardBg)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${item.boardClass} • ${item.subject} (${item.category})", fontSize = 11.sp, color = AmberAccent)
                        Text(text = item.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(text = "Price: ₹${item.price.toInt()}", fontSize = 12.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = { viewModel.deletePost(item.id) }
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = RedError)
                    }
                }
            }
        }
    }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Delete All Posts?") },
            text = { Text("Are you sure you want to delete all PDF materials from the store? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAllPosts()
                        showDeleteAllDialog = false
                    }
                ) {
                    Text("Yes, Delete All", color = RedError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun AdminSettingsTab(viewModel: AdminViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val settings = uiState.appSettings

    var upiId by remember(settings.upiId) { mutableStateOf(settings.upiId) }
    var upiName by remember(settings.upiName) { mutableStateOf(settings.upiName) }
    var announcement by remember(settings.announcement) { mutableStateOf(settings.announcement) }
    var whatsapp by remember(settings.whatsappNumber) { mutableStateOf(settings.whatsappNumber) }
    var youtubeUrl by remember(settings.youtubeUrl) { mutableStateOf(settings.youtubeUrl) }
    var telegramUrl by remember(settings.telegramUrl) { mutableStateOf(settings.telegramUrl) }
    var appLogoUrlInput by remember(settings.appLogoUrl) { mutableStateOf(settings.appLogoUrl ?: "") }
    var qrUri by remember { mutableStateOf<Uri?>(null) }
    var logoUri by remember { mutableStateOf<Uri?>(null) }

    val qrPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? -> qrUri = uri }

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? -> logoUri = uri }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardBg)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "⚙️ App Global & UPI Settings",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberAccent
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = upiId,
                    onValueChange = { upiId = it },
                    label = { Text("UPI ID (e.g. anujmaurya@upi)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = upiName,
                    onValueChange = { upiName = it },
                    label = { Text("UPI Receiver Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("WhatsApp Support Number") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = announcement,
                    onValueChange = { announcement = it },
                    label = { Text("Top Live Announcement Text") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = youtubeUrl,
                    onValueChange = { youtubeUrl = it },
                    label = { Text("YouTube Channel Link") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = telegramUrl,
                    onValueChange = { telegramUrl = it },
                    label = { Text("Telegram Channel Link") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Custom QR Upload
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF475569), RoundedCornerShape(8.dp))
                        .clickable {
                            qrPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                    color = Color(0xFF0F172A)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, tint = AmberAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (qrUri != null) "New QR Image Selected ✓" else "Change UPI QR Code Image",
                            color = if (qrUri != null) GreenSuccess else Color.LightGray,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Custom App Logo Upload / Link
                OutlinedTextField(
                    value = appLogoUrlInput,
                    onValueChange = { appLogoUrlInput = it },
                    label = { Text("Logo Image Direct URL (Optional)") },
                    placeholder = { Text("https://.../logo.png") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF475569), RoundedCornerShape(8.dp))
                        .clickable {
                            logoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                    color = Color(0xFF0F172A)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, tint = AmberAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (logoUri != null) "New App Logo Selected ✓" else "Or Pick Logo from Gallery",
                            color = if (logoUri != null) GreenSuccess else Color.LightGray,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        viewModel.saveSettings(
                            upiId = upiId.trim(),
                            upiName = upiName.trim(),
                            announcement = announcement.trim(),
                            whatsapp = whatsapp.trim(),
                            youtubeUrl = youtubeUrl.trim(),
                            telegramUrl = telegramUrl.trim(),
                            upiQrUri = qrUri,
                            appLogoUri = logoUri,
                            appLogoDirectUrl = appLogoUrlInput.trim().ifBlank { null }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save & Sync Settings to Cloud", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AdminBannersTab(viewModel: AdminViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val banners = uiState.appSettings.banners

    var bannerTitle by remember { mutableStateOf("") }
    var bannerYoutubeUrl by remember { mutableStateOf("") }
    var bannerBadge by remember { mutableStateOf("TOPPER NOTES") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardBg)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "▶ Add YouTube Video Banner",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberAccent
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = bannerTitle,
                    onValueChange = { bannerTitle = it },
                    label = { Text("Banner Video Title") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = bannerYoutubeUrl,
                    onValueChange = { bannerYoutubeUrl = it },
                    label = { Text("YouTube Video URL (https://youtube.com/...)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = bannerBadge,
                    onValueChange = { bannerBadge = it },
                    label = { Text("Badge Text (e.g. TOPPER NOTES)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        if (bannerYoutubeUrl.isBlank()) return@Button
                        val newBanner = BannerItem(
                            id = "b_${System.currentTimeMillis()}",
                            title = bannerTitle.trim().ifBlank { "UP Board 2026 Strategy" },
                            youtubeUrl = bannerYoutubeUrl.trim(),
                            badgeText = bannerBadge.trim().ifBlank { "NEW VIDEO" }
                        )
                        viewModel.saveBanners(banners + newBanner)
                        bannerTitle = ""
                        bannerYoutubeUrl = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Video Banner to Home Carousel", fontWeight = FontWeight.Bold)
                }
            }
        }

        Text(
            text = "Active Carousel Banners (${banners.size})",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        banners.forEachIndexed { index, item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = AdminCardBg)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = item.badgeText, fontSize = 11.sp, color = AmberAccent, fontWeight = FontWeight.Bold)
                        Text(text = item.title, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(text = item.youtubeUrl, fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                    }

                    IconButton(
                        onClick = {
                            val updated = banners.toMutableList().apply { removeAt(index) }
                            viewModel.saveBanners(updated)
                        }
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = RedError)
                    }
                }
            }
        }
    }
}
