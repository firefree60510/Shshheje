package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppSettings
import com.example.data.model.PdfItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PdfDetailUiState(
    val isLoading: Boolean = false,
    val pdf: PdfItem? = null,
    val appSettings: AppSettings = AppSettings(),
    val error: String? = null
)

class PdfDetailViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)

    private val _uiState = MutableStateFlow(PdfDetailUiState(isLoading = true))
    val uiState: StateFlow<PdfDetailUiState> = _uiState.asStateFlow()

    fun loadPdf(id: Long) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val settings = repository.getSettings().getOrNull() ?: repository.getLocalSettings()
            val pdfRes = repository.getPdfDetails(id)
            val pdf = pdfRes.getOrNull()

            _uiState.update {
                it.copy(
                    isLoading = false,
                    pdf = pdf,
                    appSettings = settings,
                    error = if (pdf == null) "PDF Details could not be loaded." else null
                )
            }
        }
    }
}
