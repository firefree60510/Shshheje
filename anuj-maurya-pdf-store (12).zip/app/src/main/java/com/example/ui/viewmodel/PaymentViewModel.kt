package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AppSettings
import com.example.data.model.OrderResponseData
import com.example.data.model.PdfItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PaymentUiState(
    val isLoading: Boolean = false,
    val isSubmitting: Boolean = false,
    val pdf: PdfItem? = null,
    val appSettings: AppSettings = AppSettings(),
    val studentName: String = "",
    val whatsappNumber: String = "",
    val utrNumber: String = "",
    val screenshotUri: Uri? = null,
    val orderResult: OrderResponseData? = null,
    val error: String? = null
)

class PaymentViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        PaymentUiState(
            studentName = preferences.studentName,
            whatsappNumber = preferences.whatsappNumber
        )
    )
    val uiState: StateFlow<PaymentUiState> = _uiState.asStateFlow()

    fun loadPdf(pdfId: Long) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val settings = repository.getSettings().getOrNull() ?: repository.getLocalSettings()
            val pdf = repository.getPdfDetails(pdfId).getOrNull()

            _uiState.update {
                it.copy(
                    isLoading = false,
                    pdf = pdf,
                    appSettings = settings,
                    studentName = preferences.studentName,
                    whatsappNumber = preferences.whatsappNumber
                )
            }
        }
    }

    fun onStudentNameChange(name: String) {
        _uiState.update { it.copy(studentName = name) }
    }

    fun onWhatsappChange(number: String) {
        _uiState.update { it.copy(whatsappNumber = number) }
    }

    fun onUtrChange(utr: String) {
        _uiState.update { it.copy(utrNumber = utr) }
    }

    fun onScreenshotSelected(uri: Uri?) {
        _uiState.update { it.copy(screenshotUri = uri) }
    }

    fun submitPayment(onSuccess: (OrderResponseData) -> Unit) {
        val state = _uiState.value
        val pdf = state.pdf ?: return

        if (state.studentName.isBlank()) {
            _uiState.update { it.copy(error = "Please enter your name.") }
            return
        }
        if (state.whatsappNumber.isBlank() || state.whatsappNumber.length < 10) {
            _uiState.update { it.copy(error = "Please enter a valid 10-digit WhatsApp number.") }
            return
        }
        if (state.screenshotUri == null) {
            _uiState.update { it.copy(error = "Please upload the payment screenshot.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true, error = null) }
            val result = repository.submitOrder(
                screenshotUri = state.screenshotUri,
                pdfId = pdf.id,
                studentName = state.studentName.trim(),
                whatsappNumber = state.whatsappNumber.trim(),
                utrNumber = state.utrNumber.trim().ifBlank { null }
            )

            if (result.isSuccess) {
                val orderData = result.getOrNull()!!
                _uiState.update { it.copy(isSubmitting = false, orderResult = orderData) }
                onSuccess(orderData)
            } else {
                _uiState.update {
                    it.copy(
                        isSubmitting = false,
                        error = result.exceptionOrNull()?.localizedMessage ?: "Failed to submit order. Please try again."
                    )
                }
            }
        }
    }
}
