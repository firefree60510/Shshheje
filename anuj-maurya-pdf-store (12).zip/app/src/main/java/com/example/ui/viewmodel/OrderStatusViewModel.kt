package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AppSettings
import com.example.data.model.OrderItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OrderStatusUiState(
    val isLoading: Boolean = false,
    val orderIdInput: String = "",
    val whatsappInput: String = "",
    val trackedOrder: OrderItem? = null,
    val savedOrders: List<OrderItem> = emptyList(),
    val appSettings: AppSettings = AppSettings(),
    val message: String? = null,
    val error: String? = null
)

class OrderStatusViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        OrderStatusUiState(
            orderIdInput = preferences.lastOrderId,
            whatsappInput = preferences.whatsappNumber
        )
    )
    val uiState: StateFlow<OrderStatusUiState> = _uiState.asStateFlow()

    init {
        loadSettings()
        observeSavedOrders()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            val settings = repository.getSettings().getOrNull() ?: repository.getLocalSettings()
            _uiState.update { it.copy(appSettings = settings) }
        }
    }

    private fun observeSavedOrders() {
        viewModelScope.launch {
            repository.savedOrders.collect { list ->
                _uiState.update { it.copy(savedOrders = list) }
            }
        }
    }

    fun onOrderIdChange(id: String) {
        _uiState.update { it.copy(orderIdInput = id) }
    }

    fun onWhatsappChange(number: String) {
        _uiState.update { it.copy(whatsappInput = number) }
    }

    fun checkStatus() {
        val state = _uiState.value
        if (state.orderIdInput.isBlank()) {
            _uiState.update { it.copy(error = "Please enter your Order ID.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            val res = repository.checkOrderStatus(state.orderIdInput.trim(), state.whatsappInput.trim())
            if (res.isSuccess) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        trackedOrder = res.getOrNull(),
                        error = null
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = res.exceptionOrNull()?.localizedMessage ?: "Order not found. Please verify details."
                    )
                }
            }
        }
    }
}
