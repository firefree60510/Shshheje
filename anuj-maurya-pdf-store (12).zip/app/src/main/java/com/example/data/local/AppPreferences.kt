package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.BannerItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("anuj_maurya_prefs", Context.MODE_PRIVATE)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    var studentName: String
        get() = prefs.getString("student_name", "") ?: ""
        set(value) = prefs.edit().putString("student_name", value).apply()

    var whatsappNumber: String
        get() = prefs.getString("whatsapp_number", "") ?: ""
        set(value) = prefs.edit().putString("whatsapp_number", value).apply()

    var lastOrderId: String
        get() = prefs.getString("last_order_id", "") ?: ""
        set(value) = prefs.edit().putString("last_order_id", value).apply()

    var upiId: String
        get() = prefs.getString("admin_upi_id", "anujmaurya@upi") ?: "anujmaurya@upi"
        set(value) = prefs.edit().putString("admin_upi_id", value).apply()

    var upiName: String
        get() = prefs.getString("admin_upi_name", "Anuj Maurya") ?: "Anuj Maurya"
        set(value) = prefs.edit().putString("admin_upi_name", value).apply()

    var upiQrUrl: String?
        get() = prefs.getString("admin_upi_qr_url", null)
        set(value) = prefs.edit().putString("admin_upi_qr_url", value).apply()

    var announcement: String
        get() = prefs.getString(
            "admin_announcement",
            "UP Board 2025-26: Classes 6, 7, 8, 9, 10, 11 & 12 Handwritten Notes & Model Papers available!"
        ) ?: ""
        set(value) = prefs.edit().putString("admin_announcement", value).apply()

    var whatsappSupport: String
        get() = prefs.getString("admin_whatsapp", "919876543210") ?: "919876543210"
        set(value) = prefs.edit().putString("admin_whatsapp", value).apply()

    var youtubeUrl: String
        get() = prefs.getString("admin_youtube", "https://youtube.com/@anujmauryapdf") ?: "https://youtube.com/@anujmauryapdf"
        set(value) = prefs.edit().putString("admin_youtube", value).apply()

    var telegramUrl: String
        get() = prefs.getString("admin_telegram", "https://t.me/anujmauryapdf") ?: "https://t.me/anujmauryapdf"
        set(value) = prefs.edit().putString("admin_telegram", value).apply()

    var appLogoUrl: String?
        get() = prefs.getString("admin_app_logo_url", "https://lh3.googleusercontent.com/d/1NqsEISIan_jCjL587GiBpZTFH2KBwaQp")
        set(value) = prefs.edit().putString("admin_app_logo_url", value).apply()

    var homeBannerUrl: String?
        get() = prefs.getString("admin_home_banner_url", null)
        set(value) = prefs.edit().putString("admin_home_banner_url", value).apply()

    var isInitialSeeded: Boolean
        get() = prefs.getBoolean("is_initial_seeded_v3", false)
        set(value) = prefs.edit().putBoolean("is_initial_seeded_v3", value).apply()

    var isAdminLoggedIn: Boolean
        get() = prefs.getBoolean("is_admin_logged_in", false)
        set(value) = prefs.edit().putBoolean("is_admin_logged_in", value).apply()

    var homeBanners: List<BannerItem>
        get() {
            val json = prefs.getString("admin_home_banners_json", null) ?: return defaultBanners()
            return try {
                val type = Types.newParameterizedType(List::class.java, BannerItem::class.java)
                val adapter = moshi.adapter<List<BannerItem>>(type)
                adapter.fromJson(json) ?: defaultBanners()
            } catch (e: Exception) {
                defaultBanners()
            }
        }
        set(value) {
            try {
                val type = Types.newParameterizedType(List::class.java, BannerItem::class.java)
                val adapter = moshi.adapter<List<BannerItem>>(type)
                prefs.edit().putString("admin_home_banners_json", adapter.toJson(value)).apply()
            } catch (_: Exception) {}
        }

    private fun defaultBanners(): List<BannerItem> = listOf(
        BannerItem(
            id = "b1",
            title = "UP Board 2026 Topper Handwritten Notes & Strategy",
            youtubeUrl = "https://youtube.com/@anujmauryapdf",
            badgeText = "TOPPER NOTES"
        ),
        BannerItem(
            id = "b2",
            title = "Class 10 & 12 Important Model Papers Solution Video",
            youtubeUrl = "https://youtube.com/@anujmauryapdf",
            badgeText = "MODEL PAPERS"
        )
    )
}
