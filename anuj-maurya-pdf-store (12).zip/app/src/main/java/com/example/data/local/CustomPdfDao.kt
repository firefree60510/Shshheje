package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomPdfDao {
    @Query("SELECT * FROM custom_pdfs ORDER BY id DESC")
    fun getAllPdfsFlow(): Flow<List<CustomPdfEntity>>

    @Query("SELECT * FROM custom_pdfs ORDER BY id DESC")
    suspend fun getAllPdfs(): List<CustomPdfEntity>

    @Query("SELECT * FROM custom_pdfs WHERE id = :id LIMIT 1")
    suspend fun getPdfById(id: Long): CustomPdfEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPdf(pdf: CustomPdfEntity): Long

    @Query("DELETE FROM custom_pdfs WHERE id = :id")
    suspend fun deletePdfById(id: Long): Int

    @Query("DELETE FROM custom_pdfs")
    suspend fun deleteAll(): Int
}
