package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.local.CustomPdfEntity
import com.example.data.local.SavedOrderEntity
import com.example.data.model.AdminStats
import com.example.data.model.AppSettings
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.OrderResponseData
import com.example.data.model.PdfItem
import com.example.data.remote.FirestoreService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfRepository(private val context: Context) {
    private val preferences = AppPreferences(context)
    private val db = AppDatabase.getDatabase(context)
    private val orderDao = db.savedOrderDao()
    private val pdfDao = db.customPdfDao()
    val firestore = FirestoreService(context)

    val savedOrders: Flow<List<OrderItem>> = orderDao.getAllOrders().map { list ->
        list.map { it.toOrderItem() }
    }

    suspend fun getSettings(): Result<AppSettings> = withContext(Dispatchers.IO) {
        if (firestore.isAvailable()) {
            val cloudRes = firestore.getAppSettings()
            if (cloudRes.isSuccess) {
                val settings = cloudRes.getOrNull()!!
                preferences.announcement = settings.announcement
                preferences.upiId = settings.upiId
                preferences.upiName = settings.upiName
                preferences.upiQrUrl = settings.upiQrUrl
                preferences.whatsappSupport = settings.whatsappNumber
                preferences.youtubeUrl = settings.youtubeUrl
                preferences.telegramUrl = settings.telegramUrl
                if (!settings.appLogoUrl.isNullOrEmpty()) {
                    preferences.appLogoUrl = settings.appLogoUrl
                }
                if (settings.banners.isNotEmpty()) {
                    preferences.homeBanners = settings.banners
                }
                return@withContext Result.success(settings)
            }
        }
        Result.success(getLocalSettings())
    }

    suspend fun getPdfs(
        boardClass: String? = null,
        category: String? = null,
        searchQuery: String? = null
    ): Result<List<PdfItem>> = withContext(Dispatchers.IO) {
        if (firestore.isAvailable()) {
            val cloudRes = firestore.getPosts()
            if (cloudRes.isSuccess) {
                val cloudPdfs = cloudRes.getOrNull() ?: emptyList()
                if (cloudPdfs.isNotEmpty()) {
                    cloudPdfs.forEach { pdf ->
                        pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(pdf))
                    }
                    var list = cloudPdfs
                    if (!boardClass.isNullOrEmpty() && boardClass != "All") {
                        list = list.filter { it.boardClass.equals(boardClass, ignoreCase = true) }
                    }
                    if (!category.isNullOrEmpty() && category != "All") {
                        list = list.filter { it.category.equals(category, ignoreCase = true) }
                    }
                    if (!searchQuery.isNullOrBlank()) {
                        list = list.filter {
                            it.title.contains(searchQuery, ignoreCase = true) ||
                                    it.subject.contains(searchQuery, ignoreCase = true) ||
                                    it.category.contains(searchQuery, ignoreCase = true)
                        }
                    }
                    return@withContext Result.success(list)
                }
            }
        }

        ensureInitialPdfs()
        Result.success(getLocalFilteredPdfs(boardClass, category, searchQuery))
    }

    private suspend fun ensureInitialPdfs() {
        if (preferences.isInitialSeeded) return
        val existing = pdfDao.getAllPdfs()
        if (existing.isEmpty()) {
            CuratedPdfData.allPdfs.forEach { pdf ->
                pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(pdf))
                if (firestore.isAvailable()) {
                    firestore.addPost(pdf)
                }
            }
        }
        preferences.isInitialSeeded = true
    }

    private suspend fun getLocalFilteredPdfs(boardClass: String?, category: String?, query: String?): List<PdfItem> {
        val entities = pdfDao.getAllPdfs()
        var list = entities.map { it.toPdfItem() }
        if (!boardClass.isNullOrEmpty() && boardClass != "All") {
            list = list.filter { it.boardClass.equals(boardClass, ignoreCase = true) }
        }
        if (!category.isNullOrEmpty() && category != "All") {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }
        if (!query.isNullOrBlank()) {
            list = list.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.subject.contains(query, ignoreCase = true) ||
                        it.category.contains(query, ignoreCase = true)
            }
        }
        return list
    }

    suspend fun getPdfDetails(id: Long): Result<PdfItem> = withContext(Dispatchers.IO) {
        val local = pdfDao.getPdfById(id)?.toPdfItem()
            ?: CuratedPdfData.allPdfs.find { it.id == id }
            ?: CuratedPdfData.allPdfs.first()
        Result.success(local)
    }

    suspend fun addPdf(pdf: PdfItem): Result<Long> = withContext(Dispatchers.IO) {
        preferences.isInitialSeeded = true
        try {
            val entity = CustomPdfEntity.fromPdfItem(pdf).copy(id = 0)
            val newId = pdfDao.insertPdf(entity)
            val itemWithId = pdf.copy(id = newId)

            if (firestore.isAvailable()) {
                firestore.addPost(itemWithId)
            }
            Result.success(newId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePdf(id: Long): Result<Boolean> = withContext(Dispatchers.IO) {
        preferences.isInitialSeeded = true
        try {
            if (firestore.isAvailable()) {
                firestore.deletePost(id)
            }
            val rows = pdfDao.deletePdfById(id)
            Result.success(rows > 0)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteAllPdfs(): Result<Boolean> = withContext(Dispatchers.IO) {
        preferences.isInitialSeeded = true
        try {
            if (firestore.isAvailable()) {
                firestore.deleteAllPosts()
            }
            val rows = pdfDao.deleteAll()
            Result.success(rows > 0)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitOrder(
        screenshotUri: Uri,
        pdfId: Long,
        studentName: String,
        whatsappNumber: String,
        utrNumber: String?
    ): Result<OrderResponseData> = withContext(Dispatchers.IO) {
        preferences.studentName = studentName
        preferences.whatsappNumber = whatsappNumber

        val pdf = pdfDao.getPdfById(pdfId)?.toPdfItem() ?: CuratedPdfData.allPdfs.find { it.id == pdfId }
        val pdfTitle = pdf?.title ?: "UP Board PDF Material"
        val pdfPrice = pdf?.price ?: 29.0

        val cloudScreenshot = firestore.uriToBase64(screenshotUri) ?: saveScreenshotLocally(screenshotUri)

        if (firestore.isAvailable()) {
            val cloudRes = firestore.submitOrder(
                pdfId = pdfId,
                pdfTitle = pdfTitle,
                pdfPrice = pdfPrice,
                studentName = studentName,
                whatsappNumber = whatsappNumber,
                utrNumber = utrNumber,
                screenshotBase64OrUrl = cloudScreenshot
            )
            if (cloudRes.isSuccess) {
                val orderData = cloudRes.getOrNull()!!
                val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
                orderDao.insertOrder(
                    SavedOrderEntity(
                        orderId = orderData.orderId,
                        pdfId = pdfId,
                        pdfTitle = pdfTitle,
                        pdfPrice = pdfPrice,
                        studentName = studentName,
                        whatsappNumber = whatsappNumber,
                        utrNumber = utrNumber,
                        screenshotUrl = cloudScreenshot,
                        status = "Pending",
                        statusMessage = orderData.message,
                        createdAt = dateStr,
                        downloadUrl = null
                    )
                )
                preferences.lastOrderId = orderData.orderId
                return@withContext Result.success(orderData)
            }
        }

        val orderId = "AMP-" + (10000 + (Math.random() * 90000).toInt())
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())

        val savedOrder = SavedOrderEntity(
            orderId = orderId,
            pdfId = pdfId,
            pdfTitle = pdfTitle,
            pdfPrice = pdfPrice,
            studentName = studentName,
            whatsappNumber = whatsappNumber,
            utrNumber = utrNumber,
            screenshotUrl = cloudScreenshot,
            status = "Pending",
            statusMessage = "Order placed! Admin verification in progress.",
            createdAt = dateStr,
            downloadUrl = null
        )
        orderDao.insertOrder(savedOrder)
        preferences.lastOrderId = orderId

        Result.success(
            OrderResponseData(
                orderId = orderId,
                status = "Pending",
                message = "Payment screenshot uploaded successfully! Admin will verify and activate your PDF.",
                pdfTitle = pdfTitle,
                price = pdfPrice
            )
        )
    }

    private fun saveScreenshotLocally(uri: Uri): String {
        return try {
            val file = File(context.filesDir, "screenshot_${System.currentTimeMillis()}.jpg")
            val inputStream = context.contentResolver.openInputStream(uri)
            inputStream?.use { input ->
                FileOutputStream(file).use { output ->
                    input.copyTo(output)
                }
            }
            Uri.fromFile(file).toString()
        } catch (_: Exception) {
            uri.toString()
        }
    }

    suspend fun checkOrderStatus(orderId: String, whatsappNumber: String): Result<OrderItem> = withContext(Dispatchers.IO) {
        if (firestore.isAvailable()) {
            val cloudRes = firestore.checkOrderStatus(orderId, whatsappNumber)
            if (cloudRes.isSuccess) {
                val order = cloudRes.getOrNull()!!
                orderDao.updateOrderStatus(order.orderId, order.status, order.statusMessage, order.downloadUrl)
                return@withContext Result.success(order)
            }
        }

        val local = orderDao.getOrderById(orderId)
        if (local != null) {
            val cleanLocal = local.whatsappNumber.replace("+91", "").replace(" ", "").trim()
            val cleanInput = whatsappNumber.replace("+91", "").replace(" ", "").trim()
            if (cleanLocal == cleanInput || cleanLocal.isEmpty()) {
                Result.success(local.toOrderItem())
            } else {
                Result.failure(Exception("WhatsApp number does not match order record."))
            }
        } else {
            Result.failure(Exception("Order ID '$orderId' not found. Please verify."))
        }
    }

    suspend fun adminLogin(username: String, pin: String): Result<Boolean> = withContext(Dispatchers.IO) {
        if (username.equals("anujadmin", ignoreCase = true) && pin == "1234") {
            preferences.isAdminLoggedIn = true
            Result.success(true)
        } else {
            Result.failure(Exception("Invalid Admin Username or PIN. Please check credentials."))
        }
    }

    suspend fun getAdminOrders(statusFilter: String?): Result<Pair<AdminStats, List<OrderItem>>> = withContext(Dispatchers.IO) {
        if (firestore.isAvailable()) {
            val cloudRes = firestore.getAllOrders()
            if (cloudRes.isSuccess) {
                val allOrders = cloudRes.getOrNull() ?: emptyList()
                var filtered = allOrders
                if (!statusFilter.isNullOrEmpty() && statusFilter != "All") {
                    filtered = filtered.filter { it.status.equals(statusFilter, ignoreCase = true) }
                }
                val stats = AdminStats(
                    totalOrders = allOrders.size,
                    pendingOrders = allOrders.count { it.status.equals("Pending", ignoreCase = true) },
                    approvedOrders = allOrders.count { it.status.equals("Approved", ignoreCase = true) },
                    totalRevenue = allOrders.filter { it.status.equals("Approved", ignoreCase = true) }.sumOf { it.pdfPrice }
                )
                return@withContext Result.success(Pair(stats, filtered))
            }
        }
        getLocalAdminOrders(statusFilter)
    }

    private suspend fun getLocalAdminOrders(statusFilter: String?): Result<Pair<AdminStats, List<OrderItem>>> {
        val allEntities = orderDao.getAllOrdersSync()
        var list = allEntities.map { it.toOrderItem() }
        if (!statusFilter.isNullOrEmpty() && statusFilter != "All") {
            list = list.filter { it.status.equals(statusFilter, ignoreCase = true) }
        }
        val stats = AdminStats(
            totalOrders = allEntities.size,
            pendingOrders = allEntities.count { it.status == "Pending" },
            approvedOrders = allEntities.count { it.status == "Approved" },
            totalRevenue = allEntities.filter { it.status == "Approved" }.sumOf { it.pdfPrice }
        )
        return Result.success(Pair(stats, list))
    }

    suspend fun updateAdminOrderStatus(orderId: String, newStatus: String, message: String?): Result<Unit> = withContext(Dispatchers.IO) {
        orderDao.updateOrderStatus(orderId, newStatus, message, null)
        if (firestore.isAvailable()) {
            firestore.updateOrderStatus(orderId, newStatus, message, null)
        }
        Result.success(Unit)
    }

    suspend fun updateAdminSettings(
        upiId: String,
        upiName: String,
        announcement: String,
        whatsapp: String,
        youtubeUrl: String,
        telegramUrl: String,
        upiQrUrl: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        preferences.upiId = upiId
        preferences.upiName = upiName
        preferences.announcement = announcement
        preferences.whatsappSupport = whatsapp
        preferences.youtubeUrl = youtubeUrl
        preferences.telegramUrl = telegramUrl
        if (upiQrUrl != null) {
            preferences.upiQrUrl = upiQrUrl
        }

        if (firestore.isAvailable()) {
            val settings = AppSettings(
                appName = "Anuj Maurya",
                announcement = announcement,
                appLogoUrl = preferences.appLogoUrl,
                homeBannerUrl = preferences.homeBannerUrl,
                banners = preferences.homeBanners,
                upiId = upiId,
                upiName = upiName,
                upiQrUrl = upiQrUrl ?: preferences.upiQrUrl,
                whatsappNumber = whatsapp,
                youtubeUrl = youtubeUrl,
                telegramUrl = telegramUrl
            )
            firestore.saveAppSettings(settings)
        }
        Result.success(Unit)
    }

    suspend fun updateAdminBanners(banners: List<BannerItem>): Result<Unit> = withContext(Dispatchers.IO) {
        preferences.homeBanners = banners
        if (firestore.isAvailable()) {
            val current = getLocalSettings().copy(banners = banners)
            firestore.saveAppSettings(current)
        }
        Result.success(Unit)
    }

    fun saveQrUriToInternalStorage(uri: Uri): String {
        val cloudBase64 = firestore.uriToBase64(uri)
        if (cloudBase64 != null) {
            preferences.upiQrUrl = cloudBase64
            return cloudBase64
        }
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open QR image")
        val file = File(context.filesDir, "admin_upi_qr.jpg")
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        val fileUri = Uri.fromFile(file).toString()
        preferences.upiQrUrl = fileUri
        return fileUri
    }

    fun saveCoverImageToInternalStorage(uri: Uri): String {
        val cloudBase64 = firestore.uriToBase64(uri)
        if (cloudBase64 != null) {
            return cloudBase64
        }
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open Cover image")
        val fileName = "pdf_cover_${System.currentTimeMillis()}.jpg"
        val file = File(context.filesDir, fileName)
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        return Uri.fromFile(file).toString()
    }

    fun saveLogoUriToInternalStorage(uri: Uri): String {
        val cloudBase64 = firestore.uriToBase64(uri)
        if (cloudBase64 != null) {
            preferences.appLogoUrl = cloudBase64
            return cloudBase64
        }
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open Logo image")
        val file = File(context.filesDir, "app_custom_logo.jpg")
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        val fileUri = Uri.fromFile(file).toString()
        preferences.appLogoUrl = fileUri
        return fileUri
    }

    suspend fun updateAdminLogo(logoUri: Uri?): Result<String?> = withContext(Dispatchers.IO) {
        if (logoUri != null) {
            val savedUrl = saveLogoUriToInternalStorage(logoUri)
            if (firestore.isAvailable()) {
                val current = getLocalSettings().copy(appLogoUrl = savedUrl)
                firestore.saveAppSettings(current)
            }
            Result.success(savedUrl)
        } else {
            Result.success(preferences.appLogoUrl)
        }
    }

    fun getLocalSettings(): AppSettings = AppSettings(
        appName = "Anuj Maurya",
        announcement = preferences.announcement,
        appLogoUrl = preferences.appLogoUrl,
        homeBannerUrl = preferences.homeBannerUrl,
        banners = preferences.homeBanners,
        upiId = preferences.upiId,
        upiName = preferences.upiName,
        upiQrUrl = preferences.upiQrUrl,
        whatsappNumber = preferences.whatsappSupport,
        youtubeUrl = preferences.youtubeUrl,
        telegramUrl = preferences.telegramUrl,
        paymentInstructions = "1. Pay the exact PDF price using the UPI ID or QR Code.\n2. Take a screenshot of the successful payment screen.\n3. Upload screenshot with your WhatsApp number.\n4. Admin manually verifies payment and activates download."
    )
}
