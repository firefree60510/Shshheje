package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.PdfItem

@Entity(tableName = "custom_pdfs")
data class CustomPdfEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val boardClass: String,
    val subject: String,
    val category: String,
    val price: Double,
    val originalPrice: Double?,
    val description: String?,
    val previewImageUrl: String?,
    val pagesCount: Int,
    val fileSize: String?,
    val year: String?,
    val isAvailable: Boolean,
    val isFeatured: Boolean,
    val samplePreviewUrl: String?,
    val downloadUrl: String?
) {
    fun toPdfItem(): PdfItem = PdfItem(
        id = id,
        title = title,
        boardClass = boardClass,
        subject = subject,
        category = category,
        price = price,
        originalPrice = originalPrice,
        description = description,
        previewImageUrl = previewImageUrl,
        pagesCount = pagesCount,
        fileSize = fileSize,
        year = year,
        isAvailable = isAvailable,
        isFeatured = isFeatured,
        samplePreviewUrl = samplePreviewUrl,
        downloadUrl = downloadUrl
    )

    companion object {
        fun fromPdfItem(item: PdfItem): CustomPdfEntity = CustomPdfEntity(
            id = item.id,
            title = item.title,
            boardClass = item.boardClass,
            subject = item.subject,
            category = item.category,
            price = item.price,
            originalPrice = item.originalPrice,
            description = item.description,
            previewImageUrl = item.previewImageUrl,
            pagesCount = item.pagesCount,
            fileSize = item.fileSize,
            year = item.year,
            isAvailable = item.isAvailable,
            isFeatured = item.isFeatured,
            samplePreviewUrl = item.samplePreviewUrl,
            downloadUrl = item.downloadUrl
        )
    }
}
