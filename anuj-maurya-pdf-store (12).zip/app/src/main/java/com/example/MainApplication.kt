package com.example

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                try {
                    FirebaseApp.initializeApp(this)
                } catch (_: Exception) {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId(packageName)
                        .setProjectId("anuj-maurya-store")
                        .setApiKey("AIzaSyDefaultClientApiKeyForFirestore")
                        .build()
                    FirebaseApp.initializeApp(this, options)
                }
            }
        } catch (e: Exception) {
            Log.w("MainApplication", "FirebaseApp init: ${e.message}")
        }
    }
}
